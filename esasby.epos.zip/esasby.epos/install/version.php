<?
$arModuleVersion = array(
	'VERSION' => '1.12.3',
	'VERSION_DATE' => '2020-10-15 12:00:00'
);