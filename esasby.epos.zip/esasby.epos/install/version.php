<?
$arModuleVersion = array(
	'VERSION' => '1.17.5',
	'VERSION_DATE' => '2022-07-20 12:00:00'
);