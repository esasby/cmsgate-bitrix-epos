<?
$arModuleVersion = array(
	'VERSION' => '1.13.0',
	'VERSION_DATE' => '2020-11-09 12:00:00'
);