<?
$arModuleVersion = array(
	'VERSION' => '1.17.0',
	'VERSION_DATE' => '2022-07-05 12:00:00'
);