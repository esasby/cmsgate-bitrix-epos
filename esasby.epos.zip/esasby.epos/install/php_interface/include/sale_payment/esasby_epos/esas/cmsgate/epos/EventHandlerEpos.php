<?php

/**
 * Created by IntelliJ IDEA.
 * User: nikit
 * Date: 25.06.2020
 * Time: 11:03
 */
namespace cmsgate_scope_bitrix_epos\esas\cmsgate\epos;

use cmsgate_scope_bitrix_epos\esas\cmsgate\bitrix\CmsgateEventHandler;
use cmsgate_scope_bitrix_epos\esas\cmsgate\epos\controllers\ControllerEposInvoiceUpdate;
use cmsgate_scope_bitrix_epos\esas\cmsgate\Registry;
class EventHandlerEpos extends CmsgateEventHandler
{
    public static function onSaleOrderSaved(\Bitrix\Main\Event $event)
    {
        /** @var \Bitrix\Sale\Order $order */
        $order = $event->getParameter('ENTITY');
        $isNew = $event->getParameter('IS_NEW');
        $oldPrice = $event->getParameter('VALUES')['PRICE'];
        if (!$isNew && $order->getId() > 0 && $oldPrice != null) {
            $orderWrapper = Registry::getRegistry()->getOrderWrapper($order->getId());
            $controller = new ControllerEposInvoiceUpdate();
            $controller->process($orderWrapper);
        }
    }
}
