<?php

namespace cmsgate_scope_bitrix_epos;

use cmsgate_scope_bitrix_epos\esas\cmsgate\epos\RegistryEposBitrix;
use cmsgate_scope_bitrix_epos\esas\cmsgate\CmsPlugin;
if (!\class_exists("cmsgate_scope_bitrix_epos\\esas\\cmsgate\\CmsPlugin")) {
    require_once \dirname(__FILE__) . '/vendor/esas/cmsgate-core/src/esas/cmsgate/CmsPlugin.php';
    (new CmsPlugin(\dirname(__FILE__) . '/vendor', \dirname(__FILE__)))->setRegistry(new RegistryEposBitrix())->init();
}
